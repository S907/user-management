const adminModel=require('../model/admin.model');
const loggedInUserModel = require('../model/user.model');
const blogModel = require('../model/blog.model');
const faqModel = require('../model/faq.model');

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const fs = require('fs');

class AdminController{



    /**
      * @method userAuth
      * @description To authenticate users
      */
     async userAuth(req, res, next) {
        try {
            let user = req.user;
            console.log(user);
            if (user) {
                
                next();
            } else {
                res.redirect('/admin/login');
            }
        } catch (err) {
            throw err;
        }
    }

    /**
     * 
     * @method: showIndexPAge 
     * @desc: Rendering login page
     */
    async showIndexPage(req,res){
    try {
        res.render('admin/login',{
            title: 'Sb Admin Panel login',
            user: req.user
        })
        } catch (error) {
        console.log(error);
        throw(error)
        }
    }

    


    /**
     * @method: showAdminTemplate
     * @desc: to render admin template
     */

    async showAdminTemplate(req,res){
        try {
            let fetchUserDetails = await loggedInUserModel.find({isDeleted:false});
            console.log('58==>',fetchUserDetails);
            res.render('admin/template',{
                title:'Admin-template',
                userData: fetchUserDetails,
                user: req.user
            })
        } catch (error) {
            console.log(error);
        }
    }


    /**
     * @method: showRegistrationPage
     * @desc: to render regsitration page
     */
    async showRegistrationPage(req,res){
        try {
            res.render('admin/register',{
                title: 'Registration'
            })
        } catch (error) {
            console.log(error);
        }
    }

     /**
     * @method: submitRegistrationpage
     * @desc: to submit regsitration page
     */

    async submitRegistrationpage(req,res){
        try {
            req.body.firstName = req.body.firstName.trim();
            req.body.lastName = req.body.lastName.trim();
            req.body.email = req.body.email.trim();
            req.body.password = req.body.password.trim();
      
            //Checking if the fields are blank or not
            if (!req.body.firstName || !req.body.lastName || !req.body.email || !req.body.password) {
              req.flash('message', "Field Should Not Be Empty!!");
              res.redirect('register');
            }
      
            //Checking if email already exists
            let isEmailExists = await adminModel.find({ email: req.body.email });
      
            if (!isEmailExists.length) {
                req.body.image = req.file.filename
              req.body.password = bcrypt.hashSync(req.body.password, bcrypt.genSaltSync(10));
      
              let Data = await adminModel.create(req.body);
              req.body.fullName = `${req.body.firstName} ${req.body.lastName}`;
      
              //Checking to see if Data is Saved
              if (Data && Data._id) {
                console.log('message', 'Registration Successful!!');
                res.redirect('/admin/login');
              } else {
                console.log('message', 'Registration Not Successful!!');
                res.redirect('/admin/register');
              }
              console.log(Data);
            } else {
              console.log('message', 'Email Already Exists!!');
              res.redirect('/admin/register');
            }
      
          } catch (err) {
            throw err;
          }
        
    }




     /**
     * @method: signInAdmin
     * @desc: to signIn to dashboard page
     */

      async signInAdmin(req,res){
        
        
        try {
            
            req.body.email = req.body.email.trim();
            req.body.password = req.body.password.trim();

            console.log('req.user===>',req.user);

            let isUserExists = await adminModel.findOne({
                email: req.body.email
            });

            if (!req.body.password && !req.body.email) {
                res.redirect('/admin/login');
            } else {
                if (isUserExists) {
                    const hashPassword = isUserExists.password;
                    if (bcrypt.compareSync(req.body.password, hashPassword)) {
                        // token creation
                        const token = jwt.sign({
                            id: isUserExists._id,
                            email: isUserExists.email,
                            fullName: isUserExists.fullName,
                            image: isUserExists.image

                        }, 'MREW333SGYTY', { expiresIn: '24h' });

                        // req.user.token = token;
                        res.cookie('usertokken', token); // Set your cookie
                        console.log('Logged In...');

                        
                        res.redirect('/admin/dashboard');
                    } else {
                        
                        res.redirect('/admin/login');
                    }
                } else {
                    req.flash('message', 'Email does not exist!');
                    res.redirect('/admin/login');
                }
                console.log('isUserExists====>',isUserExists);
            }
        } catch (err) {
            throw err;
        }
    }
    



    /**
     * 
     * @method: showDashBoardPAge 
     * @desc: Rendering dashboard page
     */

     async showDashBoardPage(req,res){
        try {
            
            console.log('1',req.user);
            res.render('admin/dashboard',{
                title: 'Dashboard',
                user: req.user
              
            })
        } catch (error) {
            console.log(error);
        }
    }

     
    /**
     * @method: getLogout
     * @desc: to logout from the dashboard page
     */

    async getLogout(req,res){
        try {
            console.log('Cookies======>' + req.cookies);
        res.clearCookie('usertokken');
        console.log('Cookie Cleared!');
        res.redirect('/admin/login');
        } catch (error) {
            console.log(error);
        }
    }


    

    /**
     * @method: postUserDetails
     * @desc: to post user details from the user form
     */

    async postUserFormDetails(req,res){
        try {
            // console.log(req.body);
            // console.log(req.file);
            req.body.image = req.file.filename;
            req.body.firstName = req.body.firstName.trim();
            req.body.lastName = req.body.lastName.trim();
            if(!req.body.firstName && !req.body.lastName) {
                console.log('Field Should Not Be Empty');
                res.redirect('/admin/user-form')
            }
            let isEmailExists = await loggedInUserModel.find({email: req.body.email, isDeleted:false});
            if(!isEmailExists.length){
                console.log(req.body);
                req.body.fullName = `${req.body.firstName} ${req.body.lastName}`;
                let saveUserData = await loggedInUserModel.create(req.body);
                    console.log(saveUserData);
                    if(saveUserData && saveUserData._id) {
                        console.log("Data Added Successfully");
                        res.redirect('/admin/template')
    
                }else {
                    console.log('Phone No Already Exists');
                    res.redirect('/admin/user-form')
                }
            }else {
                console.log("Email Already exists");
                res.redirect('/admin/user-form');
            }
        }catch (err) {
            console.log(err);
            throw err;
    
        }
    }

     /**
     * @method: showLoggedInUser
     * @desc: to show loggedin User form after submit has been done
     */

     async showLoggedInUser(req,res){
        try {
            res.render('admin/loggedin-user-form',{
                title:'User-Form-Logged-In',
                user: req.user
            })
        } catch (error) {
            console.log(error);
        }
     }

    /**
     * @method: editUserDetails
     * @desc: to edit user details page from the edit form
     */

    async editUserEditDetails(req,res){
        try {
            let editUserData = await loggedInUserModel.find({_id: req.params.id});
            
             console.log('294',editUserData[0]);
             
            res.render('admin/edit-user-form', {
                title: 'Edit || UserDetails',
                response: editUserData[0],
                user: req.user
                
            })
        }catch (err) {
            throw err;
        }
    }

    /**
     * @method: editUserDetails
     * @desc: to edit user details page
     */
    
    async postEditUserEditDetails(req,res){
        try {
            let data = await loggedInUserModel.find({_id: req.body.id});
            console.log('304',data);
            console.log('305',req.file);
            let isEmailExists = await loggedInUserModel.find({email: req.body.email, _id: {$ne: req.body.id}},{isDeleted:false});
            console.log('314',isEmailExists);
            if(!isEmailExists.length) {
                req.body.image = req.file.filename;
                req.body.fullName = `${req.body.firstName} ${req.body.lastName}`;
                let findUserDetailsAndUpdate = await loggedInUserModel.findByIdAndUpdate(req.body.id, req.body);
                
                console.log('findUserInfo==>', findUserDetailsAndUpdate);
                fs.unlinkSync(`./public/uploads/${data[0].image}`);
                if(findUserDetailsAndUpdate && findUserDetailsAndUpdate._id) {
                    
                    console.log('loggedInUserModel Updated');
                    res.redirect('/admin/template')
                }else {
                    console.log('Something Went Wrong');
                    res.redirect('/admin/user-form')
                }
            }else {
                console.log('Email Already Exists');
                res.redirect('/admin/dashboard')
            }
        }catch (err) {
            throw err;
        }
    }

    /**
   * @method: userDelete
   * @description: Soft Deleting the Users
   */
  async userDelete(req, res) {
    try {
      let dataUpdate = await loggedInUserModel.findByIdAndUpdate(req.params.id, {
        isDeleted: true
      });
      if (dataUpdate && dataUpdate._id) {
        console.log('Data Deleted!!');
        res.redirect('/admin/template')
      } else {
        console.log('Data Not Deleted!');
        res.redirect('/admin/template')
      }
    } catch (err) {
      throw err;
    }
  }



    // Blog Part
    /**
     * @method: showBlogPage
     * @desc: to show blog page
     */

    async showBlogPage(req,res){
        try {
            res.render('admin/blog-page',{
                title: 'Blog',
                user: req.user
            })
        } catch (error) {
            console.log(error);
        }
    }

    /**
     * @method: showBlogForm
     * @desc: to show submitted blog data
     */

    async showBlogPageDetails(req,res){
        try {
            
            let blogData = await blogModel.find({})
            console.log('354', blogData);
            res.render('admin/blog-form-details',{
                title:'Blog-Form',
                blogData,
                user:req.user
            })
        } catch (error) {
            console.log(error);
        }
    }

    
    /**
     * @method: showBlogForm
     * @desc: to show blog form
     */

    async submitBlogForm(req,res){
        try {
            console.log('412',req.file);

            if(req.file && req.file.filename){
                req.body.image = req.file.filename

            }
            let submitBlogBody = await blogModel.create(req.body)
            console.log(req.body);
            if(submitBlogBody && submitBlogBody._id){
                console.log('BLog Submitted');
                res.redirect('/admin/blog-page')
            }else{
                console.log('Blog not submitted');
                res.redirect('/admin/dashboard');
            }
        } catch (error) {
            console.log(error);
        }
    }


     /**
     * @method: showBlogEditForm
     * @desc: to show blog edit form
     */

     async showBlogEditForm(req,res){
        try {
            let showBlogData = await blogModel.find({_id: req.params.id});
            console.log('435==>',showBlogData[0]);
            res.render('admin/blog-edit-page',{
                response: showBlogData[0],
                title:'Blog|| Edit',
                user: req.user
            })
            
        } catch (error) {
            console.log(error);
        }
     }


     /**
     * @method: showBlogEditForm
     * @desc: to show blog edit form
     */
     async postEditBlogForm(req,res){
        try {
            let postEditId = await blogModel.find({_id:req.body.id});
            console.log('461==>', postEditId);
            console.log('456==>',req.file);
            req.body.image = req.file.filename;
            let updateBlogData = await blogModel.findByIdAndUpdate(req.body.id, req.body);
            console.log('455==>', updateBlogData);
            if(updateBlogData && updateBlogData._id){
                console.log('Blog Updated');
                res.redirect('/admin/blog-form-details');
            }else{
                console.log('Blog Not Updated');
                res.redirect('/admin/dashboard');
            }
            
        } catch (error) {
            console.log(error);
        }
     }

     /**
     * @method: deleteBlogEditForm
     * @desc: to show blog edit form
     */
     async deleteBlogEditForm(req,res){
        try {
            try {
                let dataUpdate = await blogModel.findByIdAndUpdate(req.params.id, {
                  isDeleted: false
                });
                if (dataUpdate && dataUpdate._id) {
                  console.log('Data Deleted!!');
                  res.redirect('/admin/blog-form-details')
                } else {
                  console.log('Data Not Deleted!');
                  res.redirect('/admin/template')
                }
              } catch (err) {
                throw err;
              }
            
        } catch (error) {
            console.log(error);
        }
     }

    
    
    
     /**
     * @method: showFaqPage
     * @desc: to show faq page
     */
    async showFaqPage(req,res){
        try {
            res.render('admin/faq',{
                title:'FAQ || Submit',
                user: req.user
            })
        } catch (error) {
            console.log(error);
        }
    }



    /**
     * @method: showFaqView
     * @desc: to show faq form page
     */
    async showFaqView(req,res){
        try {
            let viewFaqData = await faqModel.find({});
            res.render('admin/faqview',{
                title:'Faq|| View',
                user: req.user,
                viewFaqData
            })
            
        } catch (error) {
            console.log(error);
        }
    }

    //showFaqEditPage
    /**
     * @method: showFaqEditPage
     * @desc: to show faq form page
     */

    async showFaqEditPage(req,res){
        try {
            let faqEditData = await faqModel.find({})
            res.render('admin/faq-edit',{
                title:"Faq || Edit",
                response:faqEditData[0],
                user:req.user

            }) 
            
        } catch (error) {
            console.log(error);
        }
    }

    /**
     * @method: postFaqEditPage
     * @desc: to show faq form page
     */
        async postFaqEditPage(req,res){
            try {
                let showHiddenData = await faqModel.find({_id:req.body.id});
                let postFaqData = await faqModel.findByIdAndUpdate(req.body.id, req.body);

                if(postFaqData && postFaqData._id){
                    console.log('data Updated');
                    res.redirect('/admin/faq-view')
                }else{
                    console.log('data not updated');
                    res.redirect('/admin/faq')
                }
            } catch (error) {
                console.log(error);
            }
        }



    /**
     * @method: postFaqFormPage
     * @desc: to show faq form page
     */

    async postFaqFormPage(req,res){
        try {
            let submitFaqData= await faqModel.create(req.body);
            console.log('428',req.body, submitFaqData);
            if(submitFaqData && submitFaqData._id){
                console.log('Faq Added');
                res.redirect('/admin/faq')
            }else{
                console.log('Faq not added');
            }
        } catch (error) {
            console.log(error)
        }
    }

}

module.exports = new AdminController()