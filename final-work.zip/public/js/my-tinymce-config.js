tinymce.init({
    selector: 'textarea'
    
  });