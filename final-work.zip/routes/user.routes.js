const router= require('express').Router();
const appControlUser = require('../controller/user.controller');






module.exports=router;